import os
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam

DATASET_DIR = "bloodcell_dataset"
IMG_SIZE = (224, 224)
BATCH = 32
EPOCHS = 1

datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

train_gen = datagen.flow_from_directory(
    os.path.join(DATASET_DIR, "train"),
    target_size=IMG_SIZE,
    batch_size=BATCH,
    class_mode="categorical"
)

val_gen = datagen.flow_from_directory(
    os.path.join(DATASET_DIR, "val"),
    target_size=IMG_SIZE,
    batch_size=BATCH,
    class_mode="categorical"
)

base = MobileNetV2(weights=None, include_top=False, input_shape=(224,224,3))

x = GlobalAveragePooling2D()(base.output)
x = Dropout(0.3)(x)
out = Dense(len(train_gen.class_indices), activation='softmax')(x)
model = Model(inputs=base.input, outputs=out)
model.compile(Adam(1e-4), loss='categorical_crossentropy', metrics=['accuracy'])

model.fit(train_gen, validation_data=val_gen, epochs=EPOCHS)
model.save("blood_cell.h5")

with open("class_labels.txt","w") as f:
    for label, idx in sorted(train_gen.class_indices.items(), key=lambda x: x[1]):
        f.write(label + "\n")
